Dependency-Check-Core
================

Dependency-Check-Core is the main engine used by all of the other modules to do the analysis and reporting.

Copyright & License
------------

Dependency-Check is Copyright (c) 2012-2014 Jeremy Long. All Rights Reserved.

Permission to modify and redistribute is granted under the terms of the Apache 2.0 license. See the [LICENSE.txt](https://raw.githubusercontent.com/jeremylong/DependencyCheck/main/LICENSE.txt) file for the full license.

Dependency-Check makes use of several other open source libraries. Please see the [NOTICE.txt][notices] file for more information.


  [wiki]: https://github.com/jeremylong/DependencyCheck/wiki
  [notices]: https://github.com/jeremylong/DependencyCheck/blob/main/NOTICE.txt
