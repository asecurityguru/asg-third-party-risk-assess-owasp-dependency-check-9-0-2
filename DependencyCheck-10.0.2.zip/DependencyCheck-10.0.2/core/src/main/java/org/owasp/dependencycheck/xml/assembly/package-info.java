/**
 * Support classes for parsing GrokAssembly output.
 */
package org.owasp.dependencycheck.xml.assembly;
