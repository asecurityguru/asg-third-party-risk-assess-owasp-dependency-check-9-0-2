/**
 * Contains classes for working with the Go Lang project data.
 */
package org.owasp.dependencycheck.data.golang;
