/**
 *
 * A collection of exception classes used within the application.
 */
package org.owasp.dependencycheck.data.update.exception;
