/**
 * Contains classes for working with the CPE Lucene Index.
 */
package org.owasp.dependencycheck.data.cpe;
