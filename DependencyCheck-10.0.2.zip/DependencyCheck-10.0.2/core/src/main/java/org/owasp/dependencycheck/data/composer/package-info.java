/**
 * Model elements for PHP Composer files
 */
package org.owasp.dependencycheck.data.composer;