/**
 * Support for Sonatype OSS Index analysis.
 */
package org.owasp.dependencycheck.data.ossindex;