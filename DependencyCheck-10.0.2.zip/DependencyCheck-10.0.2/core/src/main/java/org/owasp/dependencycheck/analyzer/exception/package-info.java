/**
 * A collection of exception classes used within the analyzers.
 */
package org.owasp.dependencycheck.analyzer.exception;
