/**
 * Contains classes used to work with the NVD CVE data.
 */
package org.owasp.dependencycheck.data.nvdcve;
