/**
 * Includes the main entry point for dependency-check.
 */
package org.owasp.dependencycheck;
