/**
 * Classes used to process the output of external tools.
 */
package org.owasp.dependencycheck.processing;
