/**
 * Contains classes used to fix XML prior to parsing.
 */
package org.owasp.dependencycheck.xml;
