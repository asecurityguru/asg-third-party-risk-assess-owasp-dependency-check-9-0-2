/**
 * Contains the core Dependency implementation.
 */
package org.owasp.dependencycheck.dependency;
