/**
 *
 * Implements a generic persisted cache that can be used to store results of external analysis between executions.<br><br>
 *
 */
package org.owasp.dependencycheck.data.cache;
