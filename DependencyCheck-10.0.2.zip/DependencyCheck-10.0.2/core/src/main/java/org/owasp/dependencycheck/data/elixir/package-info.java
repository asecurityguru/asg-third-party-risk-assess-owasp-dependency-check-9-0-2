/**
 * Contains classes for working with various Elixir project data.
 */
package org.owasp.dependencycheck.data.elixir;
