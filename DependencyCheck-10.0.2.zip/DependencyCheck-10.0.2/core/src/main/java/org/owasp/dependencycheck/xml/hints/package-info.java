/**
 * Contains classes used to parse the hints file to add evidence to dependencies.
 */
package org.owasp.dependencycheck.xml.hints;
