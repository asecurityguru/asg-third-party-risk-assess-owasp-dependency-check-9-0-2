/**
 * Contains classes for working with the CWE Database.
 */
package org.owasp.dependencycheck.data.cwe;
