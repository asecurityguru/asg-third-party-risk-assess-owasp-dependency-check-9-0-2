/**
 * Contains classes used to parse the CISA Known Exploited Vulnerability Catalog.<br><br>
 *
 */
package org.owasp.dependencycheck.data.update.cisa;
