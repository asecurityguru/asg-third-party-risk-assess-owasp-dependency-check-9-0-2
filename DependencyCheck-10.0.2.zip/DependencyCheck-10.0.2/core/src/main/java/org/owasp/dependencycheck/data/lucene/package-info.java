/**
 * Contains classes used to work with the Lucene Indexes.
 */
package org.owasp.dependencycheck.data.lucene;
