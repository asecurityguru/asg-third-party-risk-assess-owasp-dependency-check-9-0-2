/**
 * A collection of identifiers for Dependency objects.
 */
package org.owasp.dependencycheck.dependency.naming;
