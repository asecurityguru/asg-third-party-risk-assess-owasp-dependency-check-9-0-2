/**
 * Contains utility classes used to identify the ecosystem for CPEs from the NVD.
 */
package org.owasp.dependencycheck.data.nvd.ecosystem;
