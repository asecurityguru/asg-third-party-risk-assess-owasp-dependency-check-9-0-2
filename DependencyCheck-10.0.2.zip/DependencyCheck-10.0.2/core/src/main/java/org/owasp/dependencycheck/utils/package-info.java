/**
 * Includes various utility classes such as a Settings wrapper, a Checksum utility, etc.
 */
package org.owasp.dependencycheck.utils;
