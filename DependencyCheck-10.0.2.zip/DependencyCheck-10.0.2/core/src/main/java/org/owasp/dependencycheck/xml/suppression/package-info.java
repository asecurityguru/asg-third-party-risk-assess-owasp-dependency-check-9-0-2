/**
 * Contains classes used to suppress findings.
 */
package org.owasp.dependencycheck.xml.suppression;
