/**
 * Analyzers are used to inspect the identified dependencies, collect Evidence, and process the dependencies.
 */
package org.owasp.dependencycheck.analyzer;
