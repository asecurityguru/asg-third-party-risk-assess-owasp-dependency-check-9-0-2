/**
 * This package contains classes used to parse pom.xml files.
 */
package org.owasp.dependencycheck.xml.pom;
