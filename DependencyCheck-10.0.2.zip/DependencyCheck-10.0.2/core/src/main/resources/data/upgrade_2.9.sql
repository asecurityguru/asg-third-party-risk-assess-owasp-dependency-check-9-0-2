UPDATE Properties SET `value`='3.0' WHERE ID='version';
