This JSON schema has been reduced so that the parser can directly skip data which is not in use.

Se the src/main/doc folder for the originals.