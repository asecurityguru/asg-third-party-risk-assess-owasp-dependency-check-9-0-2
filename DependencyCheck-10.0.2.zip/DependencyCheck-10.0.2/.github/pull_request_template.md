## Fixes Issue #

## Description of Change

*Please add a description of the proposed change*

## Have test cases been added to cover the new functionality?

*yes/no*