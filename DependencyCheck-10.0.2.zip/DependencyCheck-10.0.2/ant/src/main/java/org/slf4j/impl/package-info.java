/**
 * This package contains the static binder for the slf4j-ant logger.
 */
package org.slf4j.impl;
