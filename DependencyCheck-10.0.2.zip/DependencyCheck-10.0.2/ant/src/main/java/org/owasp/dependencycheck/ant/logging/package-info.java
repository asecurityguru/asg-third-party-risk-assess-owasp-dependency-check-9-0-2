/**
 * This package includes the Ant task definitions.
 */
package org.owasp.dependencycheck.ant.logging;
