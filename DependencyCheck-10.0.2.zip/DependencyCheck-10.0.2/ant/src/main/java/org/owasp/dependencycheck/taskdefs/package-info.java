/**
 * This package includes the a slf4j logging implementation that wraps the Ant logger.
 */
package org.owasp.dependencycheck.taskdefs;
