/**
 * Includes the main entry point for the DependencyChecker.
 */
package org.owasp.dependencycheck;
